// Logout endpoint
