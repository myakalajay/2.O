import Layout from '@/components/Layout';
export default function Home() {
  return (
    <Layout>
      <h1>Mortgage Lending Platform</h1>
      <p>Secure role-based access for homeowners and mortgage professionals.</p>
    </Layout>
  );
}