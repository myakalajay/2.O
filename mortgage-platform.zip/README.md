# Mortgage Lending Platform

Role-based app with JWT, MongoDB, Bootstrap.